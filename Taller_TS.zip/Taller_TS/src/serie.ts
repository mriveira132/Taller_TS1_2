class MediaShow {
  constructor(
      public identifier: number,
      public title: string,
      public broadcaster: string,
      public totalSeasons: number,
      public synopsis: string,
      public officialLink: string,
      public coverArt: string
  ) {}

  displayInfo(targetElement: HTMLElement) {
      targetElement.innerHTML = `
          <div class="media-card">
              <img src="${this.coverArt}" class="card-img" alt="${this.title} cover">
              <div class="card-content">
                  <h3 class="title">${this.title}</h3>
                  <p class="description">${this.synopsis}</p>
                  <div class="details">
                      <span class="broadcaster">Broadcasted by: ${this.broadcaster}</span>
                      <span class="seasons">Total Seasons: ${this.totalSeasons}</span>
                  </div>
                  <a href="${this.officialLink}" class="official-site" target="_blank">Visit Official Site</a>
              </div>
          </div>
      `;
  }
}

export { MediaShow };