import { entertainmentData } from './data';
import { MediaShow } from './serie';

const programBody = document.querySelector('#programTable tbody') as HTMLTableSectionElement;
const detailPanel = document.getElementById('detailPanel') as HTMLDivElement;

function populateTable(shows: MediaShow[]) {
    programBody.innerHTML = '';
    
    shows.forEach(program => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${program.identifier}</td>
            <td class="clickable-title" data-ref="${program.identifier}">${program.title}</td>
            <td>${program.broadcaster}</td>
            <td>${program.totalSeasons}</td>
        `;
        programBody.appendChild(row);
    });

    const summaryRow = document.createElement('tr');
    summaryRow.innerHTML = `
        <td colspan="3" class="average-text">Average Seasons:</td>
        <td class="average-value">${calculateSeasonAverage(shows).toFixed(1)}</td>
    `;
    programBody.appendChild(summaryRow);

    document.querySelectorAll('.clickable-title').forEach(element => {
        element.addEventListener('click', () => {
            const selected = entertainmentData.find(p => p.identifier === parseInt(element.getAttribute('data-ref') || '0'));
            if(selected) selected.displayInfo(detailPanel);
        });
    });
}

function calculateSeasonAverage(shows: MediaShow[]): number {
    return shows.reduce((sum, show) => sum + show.totalSeasons, 0) / shows.length;
}

// Initialize table
populateTable(entertainmentData);