import { MediaShow } from './serie';

const entertainmentData = [
    new MediaShow(101, "Breaking Bad", "AMC", 5,
        "A chemistry teacher's transformation into a methamphetamine producer to secure his family's future.",
        "https://www.amc.com/shows/breaking-bad",
        "https://i.imgur.com/GGje0vc.jpg"),

    new MediaShow(102, "Orange Is the New Black", "Netflix", 6,
        "A woman's experiences in a minimum-security federal prison.",
        "https://www.netflix.com/title/70242311",
        "https://i.imgur.com/EvKe48G.jpg"),

    new MediaShow(103, "Game of Thrones", "HBO", 7,
        "Noble families compete for control of the Iron Throne in a fantasy realm.",
        "https://www.hbo.com/game-of-thrones",
        "https://i.imgur.com/TDCEV1S.jpg")
];

export { entertainmentData };